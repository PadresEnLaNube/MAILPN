(function($) {
	'use strict';

    $(document).ready(function() {
        $.fancybox.open($('#mailpn-popup-notice'), {touch: false});
    });
})(jQuery);