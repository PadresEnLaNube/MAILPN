(function($) {
	'use strict';

    $(document).ready(function() {
        MAILPN_Popup.open($('#mailpn-popup-notice'));
    });
})(jQuery);