(function($) {
	'use strict';

    $(document).ready(function() {
        MAILPN_Popups.open($('#mailpn-popup-notice'));
    });
})(jQuery);